import React, { useState } from "react";
import ProfileHeader from "../components/ProfileHeader";
import { FaComment, FaPencilAlt } from "react-icons/fa";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { signOut, updateProfile } from "firebase/auth";
import {db ,auth, storage} from '../fbase'
import { UpdateData, addDoc, collection } from "firebase/firestore";
import { update } from "firebase/database";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { getDownloadURL, ref, uploadString}  from "firebase/storage";
import { v4 as uuidv4 } from 'uuid';
import "../styles/MyProfile.scss";



function MyProfile({userObj}) {
  const location = useLocation(); //react-router-dom에서 제공하는 함수
  console.log(location);

  const { images} = location.state;
  const [newDisplayName , setNewDisplayName] = useState(userObj.displayName);
  console.log(userObj);
  const[attachment ,setAttachment ] = useState("");
  const navigate = useNavigate();
  const [datas, setDatas] = useState([]);
  const [talk , setTalk] = useState("");

  const onLogOutClick = () => {
    signOut(auth);
    navigate("/", { replace: true });
  };
  
  
  const onChange = (e) =>{
    e.preventDefault();
    const { target: { value } } = e;
    setNewDisplayName(value);
    console.log(value)
    }
  
  
   const onSubmit = async (e) => {
  e.preventDefault();
  try {
    let attachmentUrl = "";
    if (attachment !== "") {
      const storageRef = ref(storage, `${userObj.uid}/${uuidv4()}`);
      const response = await uploadString(storageRef, attachment, "data_url");
      attachmentUrl = await getDownloadURL(ref(storage, response.ref));
    }
    await updateProfile(userObj, {
      displayName: newDisplayName,
      photoURL: attachmentUrl !== "" ? attachmentUrl : userObj.photoURL,
    });
  } catch (e) {
    console.error("Error updating profile: ", e);
  }
  setAttachment("");
};

  const onFileChange = (e) =>{
    console.log('e->',e);
    const {target:{files}} = e;
  
    const theFile = files[0];
    console.log('theFile->',theFile);
  
    const reader = new FileReader(); //브라우저에 사진미리보기를 하고싶으면 FileReader를 사용해야된다
    reader.onloadend = (finishedEvent) => {
      console.log("finishedEvent ->" ,finishedEvent);
      const {currentTarget:{result}} = finishedEvent
      setAttachment(result);
    }
    reader.readAsDataURL(theFile); //theFile이라는 값을 U RL로 읽어서 보이게 한다
  }
  
  const onClearAttachment = () =>{
    setAttachment("");
  }
  
  console.log("attachment",attachment);
  console.log("newDisplayName ", newDisplayName )
  
  return (
    <div className="profile_wrap">
      <ProfileHeader />

      <div className="profile_main">
        <section className="background">
          <h2 className="blind">My profile background image</h2>
          <img src={images} alt="Profile image" />
        </section>
        <section className="profile">
          <h2 className="blind">My profile info</h2>
          <div className="Profile_profile_img empty">
          <img src={userObj.photoURL} alt="Profile image" />
            <images />
          </div>  
          <div className="profile_cont">
            <span className="profile_name">{userObj.displayName}</span>
            <input
              type="mail"
              className="profile_email"
              placeholder="Userid@gmail.com"
            />
            <ul className="profile_menu">
              <li>
                  <span className="icon">
                    <FaPencilAlt />
                  </span>
                  Edit Profile
              </li>
            </ul>
          </div>
          <form onSubmit={onSubmit}>
          <input type="text" onChange={onChange} value={newDisplayName} placeholder="Display Name" />
          <input type="submit" value="Update Profile" />
          <input type='file' accept='image/*' onChange={onFileChange} />
          {attachment && ( //값이 있으면 true 다, 0 null 공백문자 undefind = false
            <div>
              <img src={attachment} width="50" height="50" alt='' />
              <button onClick={onClearAttachment}>remove</button>

            </div>
            
          )}
        </form>
          <button onClick={onLogOutClick}>Log Out</button>
          <div>
          </div>
          </section>
      </div>
    </div>
  );

}
export default MyProfile;
