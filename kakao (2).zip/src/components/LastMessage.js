import React, { useEffect, useState } from "react";
import "../styles/Chats.scss";
import { collection, onSnapshot, orderBy, query, where } from "firebase/firestore";
import { db } from '../fbase'

function LastMessage(props) {
  const { chatId, isOwner ,name } = props;
  const [lastTalk, setLastTalk] = useState("");
 console.log(name);
  useEffect(() => {
    const q = query(collection(db, "talks"), 

    // where("userName.name", "==", name), 
    
    orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const newTalks = {};
      querySnapshot.forEach((doc) => {
        const talk = doc.data();
        const chatId = talk.chatId;
        if (!newTalks[chatId]) {
          newTalks[chatId] = talk;
        }
      });
      setLastTalk(newTalks[chatId]?.text || "");
    });
  }, [chatId]);

  return (
    <h4>{lastTalk}</h4>
  )
}

// useEffect(() => {
//   if (!name || !chatId || !isOwner) return;

//   const q = query(
//     collection(db, "talks"),
//     where("userName.name", "==", name),
//     orderBy("createdAt", "desc")
//   );

//   const unsubscribe = onSnapshot(q, (querySnapshot) => {
//     const newTalks = {};
//     querySnapshot.forEach((doc) => {
//       const talk = doc.data();
//       const chatId = talk.chatId;
//       if (!newTalks[chatId]) {
//         newTalks[chatId] = talk;
//       }
//     });
//     setLastTalk(newTalks[chatId]?.text || "");
//   });

//   return unsubscribe;
// }, [name, chatId, isOwner]);
//   return (
//     <h4>{lastTalk}</h4>
//   )
//   console.log(lastTalk);
// }
export default LastMessage;