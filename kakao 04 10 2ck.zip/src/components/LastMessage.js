import React, { useEffect, useState } from "react";
import "../styles/Chats.scss";
import { collection, onSnapshot, orderBy, query, where } from "firebase/firestore";
import { db } from '../fbase'
import { useLocation } from "react-router-dom";

function LastMessage({userObj}) {

  const location = useLocation(); //react-router-dom에서 제공하는 함수
  console.log("location ->",location);
  const [talks, setTalks] = useState([]);

  const { name, images, id, city , backImages, username} = location.state;

  useEffect(() =>{
    const q = query(collection(db,"talks"), where("userName.name", "==", name), orderBy("createdAt" ,"asc"));

      const unsubscribe = onSnapshot(q,(querySnapshot) => {
        const newArray = [];
        querySnapshot.forEach((doc) =>{
          newArray.push({...doc.data(), id:doc.id});
          console.log("newA->",newArray);
        });
        setTalks(newArray);
      });
  },[]);

  return (
    <h4>{userObj.text}</h4>
  )
}

export default LastMessage;